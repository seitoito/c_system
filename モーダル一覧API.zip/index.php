<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>顧客管理システム</title>
    <link rel="stylesheet" href="css\base.css">
    <link rel="stylesheet" href="css\style.css">
</head>
<body>
    <div class="container">
    <h1 style="font-size: 3em;">顧客管理システム</h1>
        <button onclick="location.href='list.php'"class="search-button">顧客一覧・検索</button>
    </div>
</body>
</html>
